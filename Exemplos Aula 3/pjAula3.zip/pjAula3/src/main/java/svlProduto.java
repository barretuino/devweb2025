import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import pjAula3.Produto;

@WebServlet("/svlProduto")
public class svlProduto extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Produto produto;
       
    public svlProduto() {
        super();
        produto = new Produto();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer codigo = Integer.parseInt(request.getParameter("codigo"));
		String descricao = request.getParameter("descricao");
		boolean status = false;
		if(request.getParameter("situacao") != null) {
			status = request.getParameter("situacao").equals("on");
		}
		
		response.getWriter().append("Cadastrado com sucesso!");
		response.getWriter().append(" Produto " + codigo);
		response.getWriter().append(" - " + descricao);
		response.getWriter().append(" situacao " + status);
		response.getWriter().append(" Data de Cadastro " +
						request.getParameter("dataCadastro"));		
		
		produto.setCodigo(codigo);
		produto.setDescricao(descricao);
		produto.setStatus(status);
	}
}
